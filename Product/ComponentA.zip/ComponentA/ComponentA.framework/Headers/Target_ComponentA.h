//
//  Target_ComponentA.h
//  ComponentA
//
//  Created by 王俣2020 on 2021/4/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface Target_ComponentA : NSObject

@end

NS_ASSUME_NONNULL_END
